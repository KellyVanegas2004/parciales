/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial01diseño;

/**
 *
 * @author USUARIO
 */
public class Cars {
    
    private String color;
    private int cost;
    private String model;
    private String make;
    private String year_production;

    public Cars(String color, int cost, String model, String make, String year_production) {
        this.color = color;
        this.cost = cost;
        this.model = model;
        this.make = make;
        this.year_production = year_production;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getYear_production() {
        return year_production;
    }

    public void setYear_production(String year_production) {
        this.year_production = year_production;
    }
    
    

}
